"""
planificadores.py
=================
Módulo de lógica pura para algoritmos de planificación del brazo del disco.
Cada función recibe los parámetros necesarios y retorna un diccionario
estructurado con la secuencia, el THM y el detalle paso a paso.

Algoritmos implementados:
  - FCFS  : First-Come, First-Served
  - SSTF  : Shortest Seek Time First
  - SCAN  : Algoritmo del Elevador
  - LOOK  : Variación inteligente de SCAN (sin llegar al límite físico)
"""


# ---------------------------------------------------------------------------
# Función auxiliar
# ---------------------------------------------------------------------------

def _build_step(origen: int, destino: int) -> dict:
    """Construye un objeto de paso con cálculo de distancia."""
    distancia = abs(destino - origen)
    return {
        "desde": origen,
        "hasta": destino,
        "distancia": distancia,
        "calculo": f"|{destino} - {origen}| = {distancia}",
    }


# ---------------------------------------------------------------------------
# FCFS – First-Come, First-Served
# ---------------------------------------------------------------------------

def fcfs(cola: list[int], cabezal: int) -> dict:
    """
    Atiende las peticiones en el orden exacto en que llegaron.

    Args:
        cola    : Lista de cilindros solicitados (en orden de llegada).
        cabezal : Posición inicial del cabezal.

    Returns:
        Diccionario con secuencia, THM y pasos detallados.
    """
    secuencia = list(cola)          # Se respeta el orden original
    pasos = []
    posicion_actual = cabezal
    thm = 0

    for destino in secuencia:
        paso = _build_step(posicion_actual, destino)
        pasos.append(paso)
        thm += paso["distancia"]
        posicion_actual = destino

    return {
        "algoritmo": "FCFS",
        "secuencia": secuencia,
        "thm": thm,
        "pasos": pasos,
    }


# ---------------------------------------------------------------------------
# SSTF – Shortest Seek Time First
# ---------------------------------------------------------------------------

def sstf(cola: list[int], cabezal: int) -> dict:
    """
    En cada paso atiende la petición más cercana al cabezal actual.

    Args:
        cola    : Lista de cilindros solicitados.
        cabezal : Posición inicial del cabezal.

    Returns:
        Diccionario con secuencia, THM y pasos detallados.
    """
    pendientes = list(cola)         # Copia mutable de la cola
    secuencia = []
    pasos = []
    posicion_actual = cabezal
    thm = 0

    while pendientes:
        # Encontrar el cilindro más cercano al cabezal actual
        mas_cercano = min(pendientes, key=lambda c: abs(c - posicion_actual))
        pendientes.remove(mas_cercano)
        secuencia.append(mas_cercano)

        paso = _build_step(posicion_actual, mas_cercano)
        pasos.append(paso)
        thm += paso["distancia"]
        posicion_actual = mas_cercano

    return {
        "algoritmo": "SSTF",
        "secuencia": secuencia,
        "thm": thm,
        "pasos": pasos,
    }


# ---------------------------------------------------------------------------
# SCAN – Algoritmo del Elevador
# ---------------------------------------------------------------------------

def scan(cola: list[int], cabezal: int, direccion: str, disco_max: int) -> dict:
    """
    El cabezal se mueve en una dirección atendiendo peticiones hasta llegar
    al extremo del disco, luego invierte la dirección.

    Args:
        cola       : Lista de cilindros solicitados.
        cabezal    : Posición inicial del cabezal.
        direccion  : 'up' (hacia números mayores) o 'down' (hacia menores).
        disco_max  : Cilindro máximo del disco (ej. 199).

    Returns:
        Diccionario con secuencia, THM y pasos detallados.
    """
    pendientes = sorted(set(cola))  # Ordenados para facilitar la lógica
    secuencia = []
    pasos = []
    posicion_actual = cabezal
    thm = 0

    # Separar peticiones a cada lado del cabezal
    izquierda = [c for c in pendientes if c < cabezal]   # Menores al cabezal
    derecha   = [c for c in pendientes if c >= cabezal]  # Mayores o iguales

    if direccion == "up":
        # Primero atiende hacia la derecha (hasta el extremo), luego izquierda
        orden = derecha + [disco_max] + list(reversed(izquierda))
    else:
        # Primero atiende hacia la izquierda (hasta el extremo), luego derecha
        orden = list(reversed(izquierda)) + [0] + derecha

    # Construir secuencia y pasos (el extremo físico no es "petición", solo
    # marca el límite de la barrida, pero sí genera movimiento)
    peticiones_set = set(cola)
    for destino in orden:
        paso = _build_step(posicion_actual, destino)
        pasos.append(paso)
        thm += paso["distancia"]
        posicion_actual = destino
        if destino in peticiones_set:
            secuencia.append(destino)

    return {
        "algoritmo": "SCAN",
        "secuencia": secuencia,
        "thm": thm,
        "pasos": pasos,
    }


# ---------------------------------------------------------------------------
# LOOK – Variación inteligente de SCAN
# ---------------------------------------------------------------------------

def look(cola: list[int], cabezal: int, direccion: str) -> dict:
    """
    Similar a SCAN, pero el cabezal NO llega hasta los extremos físicos del
    disco; invierte dirección al alcanzar la última petición de cada lado.

    Args:
        cola      : Lista de cilindros solicitados.
        cabezal   : Posición inicial del cabezal.
        direccion : 'up' (hacia números mayores) o 'down' (hacia menores).

    Returns:
        Diccionario con secuencia, THM y pasos detallados.
    """
    pendientes = sorted(set(cola))
    secuencia = []
    pasos = []
    posicion_actual = cabezal
    thm = 0

    izquierda = [c for c in pendientes if c < cabezal]
    derecha   = [c for c in pendientes if c >= cabezal]

    if direccion == "up":
        # Derecha primero, luego izquierda en reversa (sin tocar extremos)
        orden = derecha + list(reversed(izquierda))
    else:
        # Izquierda primero (reversa), luego derecha
        orden = list(reversed(izquierda)) + derecha

    for destino in orden:
        paso = _build_step(posicion_actual, destino)
        pasos.append(paso)
        thm += paso["distancia"]
        posicion_actual = destino
        secuencia.append(destino)

    return {
        "algoritmo": "LOOK",
        "secuencia": secuencia,
        "thm": thm,
        "pasos": pasos,
    }


# ---------------------------------------------------------------------------
# Función despachadora: ejecuta uno o todos los algoritmos
# ---------------------------------------------------------------------------

def ejecutar(algoritmo: str, cola: list[int], cabezal: int,
             disco_max: int, direccion: str) -> list[dict]:
    """
    Despacha la ejecución según el algoritmo solicitado.

    Args:
        algoritmo : 'FCFS', 'SSTF', 'SCAN', 'LOOK' o 'TODOS'.
        cola      : Lista de cilindros solicitados.
        cabezal   : Posición inicial del cabezal.
        disco_max : Cilindro máximo del disco.
        direccion : 'up' o 'down' (relevante para SCAN y LOOK).

    Returns:
        Lista de uno o más resultados según el algoritmo seleccionado.
    """
    mapa = {
        "FCFS": lambda: fcfs(cola, cabezal),
        "SSTF": lambda: sstf(cola, cabezal),
        "SCAN": lambda: scan(cola, cabezal, direccion, disco_max),
        "LOOK": lambda: look(cola, cabezal, direccion),
    }

    if algoritmo == "TODOS":
        return [fn() for fn in mapa.values()]

    if algoritmo not in mapa:
        raise ValueError(f"Algoritmo '{algoritmo}' no reconocido.")

    return [mapa[algoritmo]()]
