"""
app.py
======
Servidor Flask que expone la API REST para el simulador de
planificación del brazo del disco.

Endpoints:
  POST /simular  → Ejecuta el algoritmo y retorna resultados en JSON.
  GET  /         → Sirve la interfaz web (index.html).

Uso:
  pip install flask flask-cors
  python app.py
"""

from flask import Flask, request, jsonify, render_template, abort
from flask_cors import CORS
import planificadores

# ---------------------------------------------------------------------------
# Configuración de la aplicación
# ---------------------------------------------------------------------------

app = Flask(__name__, template_folder="templates")
CORS(app)   # Permite peticiones desde el frontend en cualquier origen


# ---------------------------------------------------------------------------
# Ruta principal – sirve la interfaz web
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    """Devuelve la página principal del simulador."""
    return render_template("index.html")


# ---------------------------------------------------------------------------
# Endpoint de simulación
# ---------------------------------------------------------------------------

@app.route("/simular", methods=["POST"])
def simular():
    """
    Recibe una configuración de simulación y retorna los resultados.

    Body JSON esperado:
    {
        "cola"      : "98, 183, 37, 122, 14, 124, 65, 67",
        "cabezal"   : 53,
        "disco_max" : 199,
        "algoritmo" : "FCFS",          // FCFS | SSTF | SCAN | LOOK | TODOS
        "direccion" : "up"             // up | down  (requerido para SCAN/LOOK)
    }

    Respuesta JSON:
    {
        "ok"        : true,
        "resultados": [ { "algoritmo": ..., "secuencia": [...], "thm": ..., "pasos": [...] } ]
    }
    """
    datos = request.get_json(silent=True)

    # ── Validación de presencia del cuerpo ──────────────────────────────────
    if not datos:
        return jsonify({"ok": False, "error": "Se esperaba un cuerpo JSON."}), 400

    # ── Extracción y validación de campos ───────────────────────────────────
    errores = []

    cola_raw   = datos.get("cola", "")
    cabezal    = datos.get("cabezal")
    disco_max  = datos.get("disco_max", 199)
    algoritmo  = datos.get("algoritmo", "FCFS").upper()
    direccion  = datos.get("direccion", "up").lower()

    # Parsear la cola de peticiones
    try:
        cola = [int(x.strip()) for x in cola_raw.split(",") if x.strip()]
        if not cola:
            errores.append("La cola de peticiones no puede estar vacía.")
    except ValueError:
        errores.append("La cola debe contener números enteros separados por comas.")
        cola = []

    # Validar cabezal
    if cabezal is None:
        errores.append("El campo 'cabezal' es requerido.")
    else:
        try:
            cabezal = int(cabezal)
        except (TypeError, ValueError):
            errores.append("El campo 'cabezal' debe ser un número entero.")
            cabezal = None

    # Validar disco_max
    try:
        disco_max = int(disco_max)
        if disco_max <= 0:
            errores.append("'disco_max' debe ser un entero positivo.")
    except (TypeError, ValueError):
        errores.append("'disco_max' debe ser un número entero.")
        disco_max = 199

    # Validar que los cilindros estén dentro del rango
    if cola and cabezal is not None:
        fuera = [c for c in cola if c < 0 or c > disco_max]
        if fuera:
            errores.append(
                f"Los cilindros {fuera} están fuera del rango [0, {disco_max}]."
            )
        if cabezal < 0 or cabezal > disco_max:
            errores.append(
                f"El cabezal ({cabezal}) está fuera del rango [0, {disco_max}]."
            )

    # Validar dirección
    if direccion not in ("up", "down"):
        errores.append("'direccion' debe ser 'up' o 'down'.")

    # Validar algoritmo
    algoritmos_validos = {"FCFS", "SSTF", "SCAN", "LOOK", "TODOS"}
    if algoritmo not in algoritmos_validos:
        errores.append(
            f"Algoritmo '{algoritmo}' no válido. Use: {', '.join(algoritmos_validos)}."
        )

    if errores:
        return jsonify({"ok": False, "errores": errores}), 422

    # ── Ejecución del/los algoritmos ────────────────────────────────────────
    try:
        resultados = planificadores.ejecutar(
            algoritmo=algoritmo,
            cola=cola,
            cabezal=cabezal,
            disco_max=disco_max,
            direccion=direccion,
        )
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify({"ok": True, "resultados": resultados})


# ---------------------------------------------------------------------------
# Punto de entrada
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # debug=True recarga automáticamente el servidor al editar el código.
    # Cámbialo a False en producción.
    app.run(debug=True, port=5000)
